import logging
import azure.functions as func
import json
import requests
import base64
import os
from azure.identity import DefaultAzureCredential, ClientSecretCredential

# Constants
KEYVAULT_NAME = os.getenv("KEY_VAULT_NAME")
TENANT_ID_SECRET_NAME = os.getenv("TENANT_ID_SECRET_NAME")
CLIENT_ID_SECRET_NAME = os.getenv("CLIENT_ID_SECRET_NAME")
CLIENT_SECRET_SECRET_NAME = os.getenv("CLIENT_SECRET_SECRET_NAME")
DEFAULT_WORKSPACE_NAME = os.getenv("WORKSPACE_NAME", "MyFabricWorkspace")
DEFAULT_NOTEBOOK_NAME = os.getenv("NOTEBOOK_NAME", "SampleNotebook")
CAPACITY_ID_SECRET_NAME = os.getenv("CAPACITY_ID_SECRET_NAME")
USER_EMAIL_ADMIN_ACCESS = os.getenv("USER_EMAIL_ADMIN_ACCESS")

# API Constants
KV_URI = f"https://{KEYVAULT_NAME}.vault.azure.net"
PBI_API_BASE = "https://api.fabric.microsoft.com/v1"


def validate_env_vars():
    required = {
        "KEY_VAULT_NAME": KEYVAULT_NAME,
        "TENANT_ID_SECRET_NAME": TENANT_ID_SECRET_NAME,
        "CLIENT_ID_SECRET_NAME": CLIENT_ID_SECRET_NAME,
        "CLIENT_SECRET_SECRET_NAME": CLIENT_SECRET_SECRET_NAME,
        "CAPACITY_ID_SECRET_NAME": CAPACITY_ID_SECRET_NAME
    }
    missing = [key for key, val in required.items() if not val]
    if missing:
        raise EnvironmentError(f"Missing environment variables: {', '.join(missing)}")


def get_keyvault_access_token():
    try:
        return DefaultAzureCredential().get_token("https://vault.azure.net/.default").token
    except Exception as e:
        logging.exception("Failed to get Key Vault access token")
        raise


def get_secret_from_kv(secret_name, access_token):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        url = f"{KV_URI}/secrets/{secret_name}?api-version=7.4"
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json().get("value")
    except Exception as e:
        logging.exception(f"Error retrieving secret '{secret_name}' from Key Vault")
        raise


def get_credentials():
    try:
        token = get_keyvault_access_token()
        tenant_id = get_secret_from_kv(TENANT_ID_SECRET_NAME, token)
        client_id = get_secret_from_kv(CLIENT_ID_SECRET_NAME, token)
        client_secret = get_secret_from_kv(CLIENT_SECRET_SECRET_NAME, token)
        capacity_id = get_secret_from_kv(CAPACITY_ID_SECRET_NAME, token)
        return tenant_id, client_id, client_secret, capacity_id
    except Exception as e:
        logging.exception("Error retrieving credentials from Key Vault")
        raise


def get_fabric_access_token(tenant_id, client_id, client_secret):
    try:
        return ClientSecretCredential(tenant_id, client_id, client_secret).get_token("https://api.fabric.microsoft.com/.default").token
    except Exception as e:
        logging.exception("Failed to acquire Fabric access token")
        raise


def post_request(url, headers, data):
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        if response.content:
            try:
                return response.json()
            except json.JSONDecodeError:
                logging.warning("Response content is not valid JSON.")
                return {}
        else:
            return {}
    except requests.exceptions.HTTPError:
        logging.error(f"HTTPError Response: {response.text}")
        raise
    except Exception as e:
        logging.exception("Error in POST request")
        raise

# function to provision worksapce
def create_workspace(token, name):
    url = f"{PBI_API_BASE}/workspaces"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    return post_request(url, headers, {"displayName": name})

# function to assign capacity to workspace
def assign_capacity(token, workspace_id, capacity_id):
    url = f"{PBI_API_BASE}/workspaces/{workspace_id}/assignToCapacity"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    return post_request(url, headers, {"capacityId": capacity_id})

def assign_admin_access_to_user(token, workspace_id, user_email):
    try:
        api_url = f"https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/users"
        payload = {
            "principalType": 'User',
            "identifier": user_email,
            "groupUserAccessRight": 'Member'
        }
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        response = requests.post(api_url, headers=headers, json=payload)
        return response
    except Exception as e:
        logging.exception(f"Error assigning admin access to user {user_email} in workspace {workspace_id}")
        raise

def create_notebook(token, workspace_id, name):
    url = f"{PBI_API_BASE}/workspaces/{workspace_id}/notebooks"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    notebook = {
        "cells": [],
        "metadata": {},
        "nbformat": 4,
        "nbformat_minor": 2
    }
    encoded_content = base64.b64encode(json.dumps(notebook).encode()).decode()
    data = {
        "displayName": name,
        "file": {
            "name": f"{name}.ipynb",
            "content": encoded_content
        }
    }
    return post_request(url, headers, data)


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Received request to provision Fabric workspace and notebook")

    try:
        validate_env_vars()

        tenant_id, client_id, client_secret, capacity_id = get_credentials()
        token = get_fabric_access_token(tenant_id, client_id, client_secret)

        workspace = create_workspace(token, DEFAULT_WORKSPACE_NAME)
        workspace_id = workspace.get("id")
        logging.info(f"Workspace created: {workspace_id}")

        assign_capacity(token, workspace_id, capacity_id)
        logging.info(f"Capacity assigned to workspace: {workspace_id}")

        assign_admin_access_to_user(token, workspace_id, USER_EMAIL_ADMIN_ACCESS)
        logging.info(f"{USER_EMAIL_ADMIN_ACCESS} has been assigned access to workspace: {DEFAULT_WORKSPACE_NAME}")

        notebook = create_notebook(token, workspace_id, DEFAULT_NOTEBOOK_NAME)
        notebook_id = notebook.get("id")
        logging.info(f"Notebook created: {notebook_id}")

        return func.HttpResponse(
            json.dumps({
                "success": True,
                "workspaceId": workspace_id,
                "workspaceName": DEFAULT_WORKSPACE_NAME,
                "notebookId": notebook_id,
                "notebookName": DEFAULT_NOTEBOOK_NAME,
                "message": "Workspace and notebook provisioned successfully."
            }),
            status_code=200,
            mimetype="application/json"
        )

    except Exception as e:
        logging.exception("Fabric provisioning failed")
        return func.HttpResponse(
            json.dumps({
                "success": False,
                "message": str(e)
            }),
            status_code=500,
            mimetype="application/json"
        )
